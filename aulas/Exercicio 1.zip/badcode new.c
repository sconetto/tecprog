void HandleStuff( CORP_DATA & input_record,
	const unsigned int current_quarter,
	unsigned double & estimated_revenue,
	const unsigned double year_to_date_revenue,
   	const unsigned int expense_type
	) {
		
	estimated_revenue = 0.0;
	
	const unsigned int MAX_DAYS_QUARTER = 92;
	const unsigned int NUMBER_OF_MONTHS = 12;
	const unsigned double NUMBER_OF_QUARTERS = 4.0;
	
	// 	
	for (int i = 0; i < MAX_DAYS_QUARTER; i++ ) {
   		input_record.revenue[i] = 0;
	}
	
	// 
	for (int i = 0; i < MAX_DAYS_QUARTER; i++ ) {
		input_record.expense[i] = corpExpense[ current_quarter ][ i ];
    }
    
    // 
    double termo = (year_to_date_revenue * NUMBER_OF_QUARTERS);
	estimated_revenue = termo / (double) current_quarter;

    // 
	for (int i = 1; i <= NUMBER_OF_MONTHS; i++ ) {
		profit[i] = revenue[i] - expense.year[expense_type][i];
    }
}

if ( expense_type == 1 ) {
}
		else if ( expenseType == 2 ) {
        	profit[i] = revenue[i] - expense.type[expense_type][i];
    	}
		else if ( expenseType == 3 ) {
        	profit[i] = revenue[i] - expense.type[expense_type][i];
		}
		else {
			// nothing to do
		}

COLOR_TYPE & new_color,
COLOR_TYPE & previous_color,
newColor = prevColor;

	StatusType & status,
EMP_DATA empRec,
UpdateCorpDatabase( empRec );
status = SUCCESS;
