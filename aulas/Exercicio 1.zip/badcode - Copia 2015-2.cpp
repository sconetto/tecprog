#define MAX_DAYS_QUARTER 92 //Mounth August + September + October = 92 days
#define JANUARY 1
#define DECEMBER 12
#define FIX_MONTH_INDEX 1
#define FIX_DAY_INDEX 1


/* This method will estimate the revenue based on the year to date and in the
 current quarter */
double estimate_revenue(int year_to_date_revenue, int current_quarter){
	logging.DEBUG("Starting method estimate_revenue()");
	double revenue = 0;
	revenue = year_to_date_revenue * 4.0 / (double) current_quarter;
	return revenue;
}

// This method calculates the profit of the corporation for each month
void calculate_profit (double profit[], int expense_type){
	for ( unsigned int month = JANUARY; month <= DECEMBER; month++ ){
	
		// Index actual to access the array the correct position of array
		unsigned int fixed_month = month - FIX_MONTH_INDEX;
		
		if ( expense_type == TYPE_ONE ) {
			profit[fixed_month] = revenue[fixed_month] - 
							 expense.type1[fixed_month];
		} else if ( expense_type == TYPE_TWO ) {
			profit[fixed_month] = revenue[fixed_month] - 
							 expense.type2[fixed_month];
		} else if ( expense_type == TYPE_THREE ) {
			profit[fixed_month] = revenue[fixed_month] - 
							 expense.type3[fixed_month];
		} else {
			logging.DEBUG("Invalid expense type.\n");
		}
	}
}

// This method will calculate the revenue based on expense_types and time
void update_revenue(CORP_DATA &corp_finantial_record, int current_quarter,
   double year_to_date_revenue, unsigned int expense_type ) {
	logging.WARNING("Starting method handle_stuff()\n");
	// Defining types
	const unsigned int TYPE_ONE = 1;
	const unsigned int TYPE_TWO = 2;
	const unsigned int TYPE_THREE = 3;
	
	assert(input_rec != null, "Input is null");
	logging.WARNING("corporation finantial record NULL");
	assert(expense_type >= TYPE_ONE, 
			"Invalid expense type - type less than one");  
	assert(expense_type <= TYPE_THREE, 
			"Invalid expense type - type greater than three");
	logging.DEBUG("%d - invalid type.",expense_type);
	
	
	for ( unsigned int day_quarter = FIX_DAY_INDEX; 
		day_quarter <= MAX_DAYS_QUARTER; day_quarter++ ) {
				
		// Index actual to access the correct position of array		
		unsigned int fixed_day = day_quarter - FIX_DAY_INDEX;		
		
	   	corp_finantial_record.revenue[fixed_day] = 0;	
		      	
	   	corp_finantial_record.expense[fixed_day] = 
		   			corp_expense[current_quarter][fixed_day];
	}	
}

    double &estim_revenue, 
	estim_revenue = estimate_revenue(year_to_date_revenue, current_quarter);
	
	double profit[12];
	calculate_profit (profit[12], expense_type);


	UpdateCorpDatabase( empRec );
	status = SUCCESS;
	
	newColor = prevColor;
