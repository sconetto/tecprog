void check(string user_word){
	
	assert((user_word != null), "The user word is null");
	assert((user_word != ""), "The user word is empty");
	
	string word = toLowerCase(line);
	int word_length = line.length();
	
	user_word = tolower(user_word);
	int user_word_length = user_word.length();
	
	 if(user_word == word){
		 cout << "WIN!" << endl;
	 } else {
		//Initial run through
		for(unsigned int i=0; i < line_length; i++){
			for(unsigned int j=0; j < user_word_length; j++){
				if(user_word[j] == word[i]){
					 cout << word[i];
				} else {
			        // Puts spaces to symbolize you got more than one letter,
					// but there are still letters missing.
			        if(user_word[j] != word[i]){
				         hang++;
				         cout << " ";
			        } else {
						// Nothing happens
			        }
			        
		        }
			}	
		}
	}
	
	if(hang == 1){
		hangs += "|";
	} else {
		// Nothing happens
	}
	
	 cout << "\nHangs: " << hangs <<endl;
 }

